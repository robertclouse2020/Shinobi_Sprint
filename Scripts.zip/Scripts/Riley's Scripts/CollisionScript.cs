﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionScript : MonoBehaviour {

    public KunaiThrow KunaiProperties;
    public GameObject Obsticle;
    //GameObject.FindGameObjectWithTag("Obsticle")

    void OnCollisionEnter(Collision collision)
    {
        if (collision.transform.position == Obsticle.transform.position)
        {
            KunaiProperties.isActive = false;
        }

    }
}
