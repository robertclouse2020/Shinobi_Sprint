﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KunaiMove : MonoBehaviour {
    public int speed;
    private GameObject[] Obstacle;
    private GameObject Player;
    public PlayerTeleControl teleparams;
    private bool HasCollided;
	// Use this for initialization
	
    private void Start()
    {
        Obstacle = GameObject.FindGameObjectsWithTag("Obstacle");
        Player = GameObject.FindGameObjectWithTag("Player");
        teleparams = GameObject.FindGameObjectWithTag("Controller").GetComponent<PlayerTeleControl>();
    }



    void OnCollisionEnter(Collision collision)
    {
        for (int i = 0; i < Obstacle.Length; i++)
        {
            if (collision.gameObject == Obstacle[i].gameObject)
            {
                HasCollided = true;
                teleparams.activeKunai = false;
            }
            else
            {
                HasCollided = false;
            }
        }
        if (collision.gameObject == Player.gameObject)
        {
            GameObject.Destroy(this.gameObject);
            teleparams.activeKunai = false;
            teleparams.CanTeleport = false;
            
        }
    }
    // Update is called once per frame
    void Update () {
        if (HasCollided == false)
        {
            transform.position += transform.up * speed * Time.deltaTime;
        }
        
    }
}
