﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damageplayer : MonoBehaviour {

    public int Damage;

}
