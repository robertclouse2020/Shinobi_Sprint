﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KunaiMove : MonoBehaviour {
    public int speed;
    public Vector3 startingPos;

	// Use this for initialization
	void Start () {
        startingPos = transform.position;
    }
	
	// Update is called once per frame
	void Update () {
        transform.position += transform.forward * speed * Time.deltaTime;
        if (transform.position.z <= -60)
            transform.position = startingPos;
    }
}
