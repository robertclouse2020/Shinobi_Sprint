﻿using UnityEngine;
using System.Collections;
//using UnityStandardAssets.Characters.ThirdPerson;
//using UnityEngine.PostProcessing;
//using UnityStandardAssets.ImageEffects;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{

    GameObject[] pauseObjects;
    //public GameObject FPController;
    public string ReloadLevel;
    public bool isActive = false;

    // Use this for initialization
    void Start()
    {
        Time.timeScale = 1;
        pauseObjects = GameObject.FindGameObjectsWithTag("ShowOnPause");
        hidePaused();
        //Cursor.lockState = CursorLockMode.Confined;
    }

    // Update is called once per frame
    void Update()
    {

        //uses the Escape button to pause and unpause the game

        if (Input.GetKeyDown(KeyCode.P))
        {
            if (Time.timeScale == 1)
            {

                isActive = true;
                Time.timeScale = 0;
                //Cursor.visible = true;
                //Cursor.lockState = CursorLockMode.Confined;
                showPaused();
                //FPController.GetComponent<ThirdPersonCharacter>().enabled = false;
                //Camera.main.GetComponent<PostProcessingBehaviour>().profile.depthOfField.enabled = true;
                //Camera.main.GetComponent<PostProcessingBehaviour>().profile.colorGrading.enabled = true;
                //Camera.main.GetComponent<PostProcessingBehaviour>().profile.grain.enabled = true;
                //Camera.main.GetComponent<PostProcessingBehaviour>().profile.vignette.enabled = true;
                ////Camera.main.GetComponent<Blur>().enabled = true;
                ////Camera.main.GetComponent<Grayscale>().enabled = true;

            }
        }


    }


    //QUIT - Reloads the Level from Start Point
    public void QUIT(string scenename)
    {
        SceneManager.LoadScene(scenename);
        //Camera.main.GetComponent<PostProcessingBehaviour>().profile.depthOfField.enabled = false;
        //Camera.main.GetComponent<PostProcessingBehaviour>().profile.colorGrading.enabled = false;
        //Camera.main.GetComponent<PostProcessingBehaviour>().profile.grain.enabled = false;
        //Camera.main.GetComponent<PostProcessingBehaviour>().profile.vignette.enabled = false;
    }

    //RESUME - controls the unpausing of the scene
    public void RESUME()
    {
        if (Time.timeScale == 1)
        {
            Time.timeScale = 0;
            //Cursor.visible = true;
            showPaused();
            isActive = false;
        }
        else if (Time.timeScale == 0)
        {
            
            Time.timeScale = 1;
            //Cursor.visible = false;
            hidePaused();
            //FPController.GetComponent<ThirdPersonCharacter>().enabled = true;
            //Camera.main.GetComponent<PostProcessingBehaviour>().profile.depthOfField.enabled = false;
            //Camera.main.GetComponent<PostProcessingBehaviour>().profile.colorGrading.enabled = false;
            //Camera.main.GetComponent<PostProcessingBehaviour>().profile.grain.enabled = false;
            //Camera.main.GetComponent<PostProcessingBehaviour>().profile.vignette.enabled = false;
            //Camera.main.GetComponent<Blur>().enabled = false;
            //Camera.main.GetComponent<Grayscale>().enabled = false;
        }
    }

    //shows objects with ShowOnPause tag
    public void showPaused()
    {
        foreach (GameObject g in pauseObjects)
        {
            g.SetActive(true);
            //g.GetComponent<Image>().CrossFadeAlpha(1.0f, 0.2f, false);
            //g.GetComponent<Text>().CrossFadeAlpha(1.0f, 0.2f, false);
        }
    }

    //hides objects with ShowOnPause tag
    public void hidePaused()
    {
        foreach (GameObject g in pauseObjects)
        {
            g.SetActive(false);
        }
    }

    //loads inputted level
    public void LoadLevel(string level)
    {
        SceneManager.LoadScene(level);
    }
}