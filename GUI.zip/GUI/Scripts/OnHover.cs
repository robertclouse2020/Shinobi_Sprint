﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class OnHover : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{

   // public Texture LoadBG_Hover;
    public Text text;
    public Image button;

    public void OnPointerEnter(PointerEventData eventData)
    {
        button.CrossFadeAlpha(0.0f, 0.2f, true);
        text.CrossFadeAlpha(0.0f, 0.2f, true);

    }

    public void OnPointerExit(PointerEventData eventData)
    {
        button.CrossFadeAlpha(1.0f, 0.2f, true);
        text.CrossFadeAlpha(1.0f, 0.2f, true);
    }
}
